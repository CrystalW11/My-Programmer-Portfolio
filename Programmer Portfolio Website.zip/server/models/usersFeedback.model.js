/** @format */

import { Schema, model } from "mongoose";

const usersFeedbackSchema = new Schema(
  {
    firstName: {
      type: String,
      required: [true, "First name is required!"],
      minlength: [3, "First name must be a minimum of 3 characters!"],
      maxlength: [30, "First name must be no more then 50 characters!"],
    },
    lastName: {
      type: String,
      required: [true, "Last name is required!"],
      minlength: [3, "Last name must be a minimum of 3 characters!"],
      maxlength: [30, "Last name must be no more then 50 characters!"],
    },
    feedback: {
      type: String,
      required: [true, "Feedback is required!"],
      minlength: [3, "Feedback characters must be a minimum of 3 characters!"],
      maxlength: [70, "Feedback must me no more then 150 characters"],
    },
    positionTitle: {
      type: String,
      required: [true, "Position Title is required!"],
      minlength: [3, "Position Title must be a minimum of 3 characters!"],
      maxlength: [20, "Position Title must me no more then 150 characters"],
    },
    companyName: {
      type: String,
      required: [true, "Company Name is required!"],
      minlength: [
        3,
        "Company Name characters must be a minimum of 3 characters!",
      ],
      maxlength: [20, "Company Name must me no more then 20 characters"],
    },
    actions: {
      type: String,
    },
  },
  { timestamps: true }
);
const UsersFeedback = model("UsersFeedback", usersFeedbackSchema);
export default UsersFeedback;
