/** @format */

import { Router } from "express";
import * as usersFeedbackController from "../controllers/usersFeedback.controllers.js";
const router = Router();
router.route("/test").get(usersFeedbackController.test);
router
  .route("/usersFeedbacks")
  .get(usersFeedbackController.getAllUsersFeedback)
  .post(usersFeedbackController.createUsersFeedback);
router
  .route("/usersFeedbacks/:id")
  .get(usersFeedbackController.getOneUsersFeedbackById)
  .delete(usersFeedbackController.deleteById)
  .put(usersFeedbackController.updateUsersFeedbackById);

export default router;
