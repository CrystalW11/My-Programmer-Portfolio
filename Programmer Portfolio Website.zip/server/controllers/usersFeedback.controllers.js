/** @format */
import UsersFeedback from "../models/usersFeedback.model.js";

async function test(req, res) {
  res.json({ message: "connected" });
}

async function createUsersFeedback(req, res) {
  try {
    const usersFeedback = await UsersFeedback.create(req.body);
    // 200 for successful posts requests
    return res.status(201).json(usersFeedback);
  } catch (err) {
    return res.status(500).json(err);
  }
}
async function getAllUsersFeedback(req, res) {
  try {
    const allUsersFeedback = await UsersFeedback.find();
    // 200 for successful get requests
    return res.status(200).json(allUsersFeedback);
  } catch (err) {
    return res.status(500).json(err);
  }
}
async function getOneUsersFeedbackById(req, res) {
  try {
    const id = req.params.id;
    const usersFeedback = await UsersFeedback.findById(id);
    // 200 for successful get requests
    return res.status(200).json(usersFeedback);
  } catch (err) {
    return res.status(500).json(err);
  }
}

async function deleteById(req, res) {
  try {
    const id = req.params.id;
    await UsersFeedback.deleteOne({ _id: id });
    const updatedUsersFeedbackList = await UsersFeedback.find();
    return res.status(200).json(updatedUsersFeedbackList);
  } catch (err) {
    return res.status(500).json(err);
  }
}
async function updateUsersFeedbackById(req, res) {
  try {
    const id = req.params.id;
    const updatedUsersFeedback = await UsersFeedback.findByIdAndUpdate(
      id,
      req.body,
      {
        runValidators: true,
        new: true,
      }
    );
    return res.status(200).json(updatedUsersFeedback);
  } catch (err) {
    return res.status(500).json(err);
  }
}

export {
  test,
  createUsersFeedback,
  getAllUsersFeedback,
  getOneUsersFeedbackById,
  deleteById,
  updateUsersFeedbackById,
};
